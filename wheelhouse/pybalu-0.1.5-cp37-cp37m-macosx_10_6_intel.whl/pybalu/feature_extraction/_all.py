__all__ = ['all']

def all(image):
    return image.flatten()