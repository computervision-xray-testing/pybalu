from . import classification
from . import data_selection
from . import feature_analysis
from . import feature_extraction
from . import feature_selection
from . import feature_transformation
from . import img_processing
from . import IO
from . import misc
from . import performance_eval
from . import utils

__version__ = '0.1.5'