__all__ = ['confusion']

from sklearn.metrics import confusion_matrix as confusion