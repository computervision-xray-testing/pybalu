__all__ = ['mutual_info']

def mutual_info(features, classification, p=None):
    raise NotImplementedError()