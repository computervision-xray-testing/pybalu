__all__ = ['mRMR']

def mRMR(features, classification, p=None):
    raise NotImplementedError()