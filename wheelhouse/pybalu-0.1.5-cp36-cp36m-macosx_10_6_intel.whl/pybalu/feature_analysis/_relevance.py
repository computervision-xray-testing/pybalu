__all__ = ['relevance']

def relevance(features, classification, p=None):
    raise NotImplementedError()